import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import 'package:rendu_flutter/models/user.dart';
import 'package:rendu_flutter/data_base/database_connection.dart';


class UserController {
  final DatabaseConnection _databaseConnection;

  UserController(this._databaseConnection);

  Future<int> insertUser(User user) async {
    final db = await _databaseConnection.setDatabase();
    return await db.insert('users', user.toJson());
  }

  Future<int> updateUser(User user) async {
    final db = await _databaseConnection.setDatabase();
    return await db.update(
      'users',
      user.toJson(),
      where: 'id = ?',
      whereArgs: [user.id],
    );
  }

  Future<int> deleteUser(int userId) async {
    final db = await _databaseConnection.setDatabase();
    return await db.delete(
      'users',
      where: 'id = ?',
      whereArgs: [userId],
    );
  }

  Future<List<User>> getUsers() async {
    final db = await _databaseConnection.setDatabase();
    final List<Map<String, dynamic>> maps = await db.query('users');
    return List.generate(maps.length, (i) {
      return User.fromJson(maps[i]);
    });
  }
}

