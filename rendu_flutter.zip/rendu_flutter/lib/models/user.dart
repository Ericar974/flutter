class User {
  int id;
  int userId;
  String userName;
  String userPassword;

  User({
    required this.id,
    required this.userId,
    required this.userName,
    required this.userPassword,
  });

  factory User.fromJson(Map<String, dynamic> json) {
    return User(
      id: json['id'] as int,
      userId: json['userId'] as int,
      userName: json['userName'] as String,
      userPassword: json['userPassword'] as String,
    );
  }

  Map<String, dynamic> toJson() => {
    'id': id,
    'userId': userId,
    'userName': userName,
    'userPassword': userPassword,
  };

  User copyWith({
    int? id,
    int? userId,
    String? userName,
    String? userPassword,
  }) {
    return User(
      id: id ?? this.id,
      userId: userId ?? this.userId,
      userName: userName ?? this.userName,
      userPassword: userPassword ?? this.userPassword,
    );
  }

}
