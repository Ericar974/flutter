import 'package:flutter/material.dart';

class UserInformationPage extends StatefulWidget {
  final int id;
  final int userId;
  final String userName;
  final String userPassword;

  UserInformationPage({
    required this.id,
    required this.userId,
    required this.userName,
    required this.userPassword,
  });

  @override
  _UserInformationPageState createState() => _UserInformationPageState();
}

class _UserInformationPageState extends State<UserInformationPage> {

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Informations ${widget.userName}'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Text('ID : ${widget.id}'),
            Text('User ID : ${widget.userId}'),
            Text('Nom d\'utilisateur : ${widget.userName}'),
            Text('Mot de passe : ${widget.userPassword}'),
            SizedBox(height: 16.0),
            ElevatedButton(
              onPressed: () {
                // Ajoutez ici la logique pour enregistrer les données en base de données
              },
              child: Text('Enregistrer en base de données'),
            ),
            ElevatedButton(
              onPressed: () {
                // Ajoutez ici la logique pour mettre à jour les données de l'utilisateur
              },
              child: Text('Mettre à jour les données'),
            ),
          ],
        ),
      ),
    );
  }
}
