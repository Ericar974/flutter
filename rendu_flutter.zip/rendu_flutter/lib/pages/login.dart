import 'package:flutter/material.dart';
import 'package:rendu_flutter/pages/user_information.dart';

class LoginPage extends StatefulWidget {
  @override
  _LoginPageState createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _userNameController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Login'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Image.asset('assets/image.png'),
              TextFormField(
                controller: _userNameController,
                decoration: InputDecoration(labelText: 'Nom d\'utilisateur'),
                validator: (value) {
                  if (value!.isEmpty) {
                    return 'Veuillez saisir un nom d\'utilisateur';
                  }
                  return null;
                },
              ),
              TextFormField(
                controller: _passwordController,
                decoration: InputDecoration(labelText: 'Mot de passe'),
                obscureText: true,
                validator: (value) {
                  if (value!.isEmpty) {
                    return 'Veuillez saisir un mot de passe';
                  }
                  return null;
                },
              ),
              SizedBox(height: 16.0),
              ElevatedButton(
                onPressed: () {
                  // Rediriger vers la page UserInformationPage
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => UserInformationPage(
                        id: 1, // Remplacez par l'ID de l'utilisateur
                        userId: 1, // Remplacez par l'User ID
                        userName: 'Armand', // Remplacez par le nom d'utilisateur
                        userPassword: '123', // Remplacez par le mot de passe
                      ),
                    ),
                  );
                },
                child: Text('Se connecter'),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  void dispose() {
    _userNameController.dispose();
    _passwordController.dispose();
    super.dispose();
  }
}
