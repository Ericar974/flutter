import 'package:flutter/material.dart';
import 'package:rendu_flutter/pages/login.dart';
import 'package:rendu_flutter/pages/user_information.dart';

class MyApp extends StatelessWidget {
  const MyApp({Key? key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Mon Application',
      theme: ThemeData(
        primaryColor: Colors.blue,
        hintColor: Colors.green,
        fontFamily: 'Roboto',
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepOrange),
        useMaterial3: true,
      ),
      routes: {
        '/': (context) => LoginPage(), // Page de connexion (route par défaut)
        '/user_information': (context) => UserInformationPage(id: 1, userId: 1, userName: '', userPassword: '',),
      },
    );
  }
}
